#' @section Installation:
#' Package 'survivalmodels' is not on CRAN and has to be install from GitHub via
#' `remotes::install_github("RaphaelS1/survivalmodels")`.
