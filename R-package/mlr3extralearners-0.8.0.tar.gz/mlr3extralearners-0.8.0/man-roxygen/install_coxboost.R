#' @section Installation:
#' The package 'CoxBoost' is not on CRAN and has to be installed from GitHub using
#' `remotes::install_github("binderh/CoxBoost")`.
