# It does not make sense to test the parameters because they are not accessible within
# R but only listed online: https://catboost.ai/docs/concepts/r-reference_catboost-train.html
