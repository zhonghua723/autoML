Please go the the `Preview` tab and select the appropriate sub-template:

* [New Learner](?expand=1&template=new_learner.md)
* [Other](?expand=1&template=other.md)
