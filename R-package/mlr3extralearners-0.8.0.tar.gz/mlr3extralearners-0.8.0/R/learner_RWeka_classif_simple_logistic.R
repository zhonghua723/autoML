#' @title Classification SimpleLogistic Learner
#' @author damirpolat
#' @name mlr_learners_classif.simple_logistic
#'
#' @description
#' LogitBoost with simple regression functions as base learners.
#' Calls [RWeka::make_Weka_classifier()] from \CRANpkg{RWeka}.
#'
#' @section Custom mlr3 parameters:
#' - `output_debug_info`:
#'   - original id: output-debug-info
#'
#' - `do_not_check_capabilities`:
#'   - original id: do-not-check-capabilities
#'
#' - `num_decimal_places`:
#'   - original id: num-decimal-places
#'
#' - `batch_size`:
#'   - original id: batch-size
#'
#' - Reason for change: This learner contains changed ids of the following control arguments
#' since their ids contain irregular pattern
#'
#' @templateVar id classif.simple_logistic
#' @template learner
#'
#' @references
#' `r format_bib("landwehr2005logistic", "Sumner2005")`
#'
#' @template seealso_learner
#' @template example
#' @export
LearnerClassifSimpleLogistic = R6Class("LearnerClassifSimpleLogistic",
  inherit = LearnerClassif,
  public = list(
    #' @description
    #' Creates a new instance of this [R6][R6::R6Class] class.
    initialize = function() {
      param_set = ps(
        subset = p_uty(tags = "train"),
        na.action = p_uty(tags = "train"),
        I = p_int(tags = "train"),
        S = p_lgl(default = FALSE, tags = "train"),
        P = p_lgl(default = FALSE, tags = "train"),
        M = p_int(tags = "train"),
        H = p_int(default = 50L, tags = "train"),
        W = p_dbl(default = 0L, tags = "train"),
        A = p_lgl(default = FALSE, tags = "train"),
        output_debug_info = p_lgl(default = FALSE, tags = "train"),
        do_not_check_capabilities = p_lgl(default = FALSE,
                                          tags = "train"),
        num_decimal_places = p_int(default = 2L, lower = 1L,
                                   tags = "train"),
        batch_size = p_int(default = 100L, lower = 1L, tags = "train"),
        options = p_uty(default = NULL, tags = "train")
      )

      super$initialize(
        id = "classif.simple_logistic",
        packages = "RWeka",
        feature_types = c("logical", "integer", "numeric", "factor", "ordered"),
        predict_types = c("response", "prob"),
        param_set = param_set,
        properties = c("missings", "multiclass", "twoclass"),
        man = "mlr3extralearners::mlr_learners_classif.simple_logistic",
        label = "LogitBoost Based Logistic Regression"
      )
    }
  ),

  private = list(
    .train = function(task) {
      weka_learner = RWeka::make_Weka_classifier("weka/classifiers/functions/SimpleLogistic")
      pars = self$param_set$get_values(tags = "train")
      rweka_train(task$data(), task$formula(), pars, weka_learner)
    },

    .predict = function(task) {
      pars = self$param_set$get_values(tags = "predict")
      newdata = ordered_features(task, self)
      rweka_predict(newdata, pars, self$predict_type, self$model)
    }
  )
)

.extralrns_dict$add("classif.simple_logistic", LearnerClassifSimpleLogistic)
