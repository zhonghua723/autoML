kdepairs <-
function(x, ...) UseMethod("kdepairs")

