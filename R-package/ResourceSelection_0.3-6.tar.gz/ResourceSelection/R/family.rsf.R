family.rsf <-
function (object, ...)
{
    binomial(object$link)
}

